#!/usr/bin/env python3
"""
Create ClickUp Meeting Notes Task
Accepts meeting notes text (direct string or file path) and creates a properly formatted task in Meeting Notes list.
"""

import sys
import json
import argparse
import os
from datetime import datetime
import time
from pathlib import Path
import re

# Set UTF-8 encoding for stdout/stderr to handle emojis on Windows
if sys.stdout.encoding.lower() != 'utf-8':
    try:
        sys.stdout.reconfigure(encoding='utf-8')
    except AttributeError:
        pass # Python < 3.7 or other environment

# Add scripts to path and resolve the external repo.
sys.path.append(str(Path(__file__).parent))
from common import setup_path
setup_path()

try:
    from clickup_client import ClickUpClient, API_URL
except ImportError:
    print("Error: Could not import clickup_client. Make sure the ClickUp skill mount is available.")
    sys.exit(1)

# Constants from config
MEETING_NOTES_LIST_ID = "901107655225"
DAVE_USER_ID = "80264"

# Custom field IDs for Meeting Notes list
CF_MEETING_DATE = "19408341-d116-45fc-b30e-8a3a2bbbadbf"
CF_FOLLOW_UP = "9ddd4ccd-5461-4105-af17-d106f64ceb7f"
CF_ATTENDEES = "824ed3e1-4b33-4d24-b216-77a4fca891d7"
CF_DISCUSSION_SUMMARY = "18f5efa8-1bfc-404b-9534-18f488015ec0"
CF_ACTION_ITEMS = "40406b46-b70b-4c38-9b85-3fd5bb6a715a"

# Follow Up options
FOLLOW_UP_YES = "904d53a4-615f-4876-9d39-3d3ac2f66fc6"
FOLLOW_UP_NO = "a3767735-31ae-4bde-9509-2e4aec952a1f"


def parse_meeting_notes(text):
    """
    Parse meeting notes text to extract key information.

    Looks for:
    - Meeting date (from title, **Started:** line, or **Date:** line)
    - Attendees (from **Attendees:** section)
    - Action items (from Action Items section)
    """
    meeting_date = None
    attendees = None
    has_action_items = False
    
    lines = text.split('\n')
    for i, line in enumerate(lines):
        line = line.strip()
        if not line:
            continue
            
        # 1. Try to find date in Title (# Title - Date)
        if line.startswith('#'):
            # Check for action items header first
            if 'action items' in line.lower():
                has_action_items = True
            
            # Formats: YYYY-MM-DD, Month DD, YYYY
            date_match = re.search(r'(\d{4}-\d{2}-\d{2})', line)
            if date_match:
                try:
                    meeting_date = datetime.strptime(date_match.group(1), '%Y-%m-%d').date()
                except ValueError:
                    pass
            else:
                # Month DD, YYYY (e.g. January 8, 2026)
                date_match = re.search(r'([A-Z][a-z]+ \d{1,2}, \d{4})', line)
                if date_match:
                    try:
                        meeting_date = datetime.strptime(date_match.group(1), '%B %d, %Y').date()
                    except ValueError:
                        pass

        # 2. Try to find "Started" line (flexible)
        elif 'Started' in line:
            # Check "Started at ... on DD Mon"
            # Example: 🕞 Started at 10:00AM on 12 Jan, lasted 30m
            match = re.search(r'on (\d{1,2} [A-Z][a-z]+)(?:,|$|\s)', line)
            if match:
                date_str = match.group(1)
                # Append current year if missing
                try:
                    # Parse "12 Jan" -> 1900-01-12
                    parsed = datetime.strptime(date_str, '%d %b')
                    # Set year to current year
                    meeting_date = parsed.replace(year=datetime.now().year).date()
                except ValueError:
                     # Try "12 January"
                    try:
                        parsed = datetime.strptime(date_str, '%d %B')
                        meeting_date = parsed.replace(year=datetime.now().year).date()
                    except ValueError:
                        pass
            
            # Check explicit full date match in line
            if not meeting_date:
                match = re.search(r'(\d{2} [A-Z][a-z]+ \d{4})', line)
                if match:
                    try:
                        meeting_date = datetime.strptime(match.group(1), '%d %b %Y').date()
                    except ValueError:
                        pass

        # 3. Try to find **Date:** line
        elif '**Date:**' in line or line.startswith('Date:'):
            date_str = line.replace('**Date:**', '').replace('Date:', '').strip()
            try:
                meeting_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            except ValueError:
                pass

        # 4. Parse Attendees
        elif '**Attendees:**' in line:
            content = line.replace('**Attendees:**', '').strip()
            if content:
                attendees = content
            elif i + 1 < len(lines):
                next_line = lines[i + 1].strip()
                if next_line and not next_line.startswith(('-', '*', '#')):
                    attendees = next_line

        # 5. Parse Action Items presence (handled in header check above)

    return meeting_date, attendees, has_action_items


def create_meeting_notes(notes_text, assignees=None, meeting_date=None):
    """
    Create a meeting notes task in ClickUp with proper formatting.

    Args:
        notes_text: Full meeting notes in markdown format
        assignees: Comma-separated list of attendee names (for parsing)
        meeting_date: datetime.date object (overrides parsed date)

    Returns:
        Task URL and validation results
    """
    client = ClickUpClient()

    # Parse notes for metadata
    parsed_date, parsed_attendees, has_action_items = parse_meeting_notes(notes_text)

    # Use provided meeting_date if given, otherwise use parsed date
    final_date = meeting_date or parsed_date

    # Generate task name from notes
    raw_title = notes_text.split('\n')[0].strip('#').strip()
    
    # Check if title already starts with the date to prevent duplication
    date_prefix = ""
    if final_date:
        date_prefix = final_date.strftime('%Y-%m-%d')
    
    if final_date and not raw_title.startswith(date_prefix):
        task_name = f"{date_prefix} {raw_title}"
    else:
        task_name = raw_title

    if len(task_name) > 100:
        task_name = task_name[:97] + '...'

    # Determine Follow Up value
    follow_up_value = FOLLOW_UP_YES if has_action_items else FOLLOW_UP_NO

    # Build custom fields
    custom_fields = [
        {"id": CF_FOLLOW_UP, "value": follow_up_value}
    ]

    # Set meeting date if available
    if final_date:
        ts = int(datetime.combine(final_date, datetime.min.time()).timestamp()) * 1000
        custom_fields.append({"id": CF_MEETING_DATE, "value": ts})  # type: ignore

    # Set attendees if parsed
    if parsed_attendees:
        custom_fields.append({"id": CF_ATTENDEES, "value": parsed_attendees})

    # Prepare assignees (meeting notes should not have assignees)
    task_assignees = []

    # Create task
    data = {
        "name": task_name,
        "markdown_description": notes_text,
        "priority": 3,
        "assignees": task_assignees,
        "custom_fields": custom_fields
    }

    print(f"Creating meeting notes task...")
    print(f"  Name: {task_name}")
    print(f"  Date: {final_date or 'N/A'}")
    print(f"  Follow Up: {'Yes' if has_action_items else 'No'}")

    response = client.create_task(
        list_id=MEETING_NOTES_LIST_ID,
        name=task_name,
        description=notes_text,
        priority=3,
        assignees=task_assignees,
        custom_fields=custom_fields
    )

    task_id = response.get('id')
    task_url = response.get('url')

    print(f"\n✅ Task created!")
    print(f"  ID: {task_id}")
    print(f"  URL: {task_url}")

    # VALIDATION: Fetch task to confirm fields were set correctly
    print(f"\n🔍 Validating task...")
    time.sleep(1)  # Brief pause to ensure consistency

    task = client.get_task(task_id)
    # Handle response structure (direct or wrapped)
    task_data = task.get('task', task) if 'id' not in task else task
    
    validation_passed = True
    issues = []

    # Check custom fields
    task_custom_fields = task_data.get('custom_fields', [])
    cf_map = {}
    for cf in task_custom_fields:
        val = cf.get('value')
        cf_map[cf.get('id')] = val

    if CF_FOLLOW_UP not in cf_map:
        issues.append("❌ Follow Up field not set")
        validation_passed = False
    else:
        # Check against option ID or index
        actual_val = cf_map[CF_FOLLOW_UP]
        if isinstance(actual_val, int):
             # Simplified check for now - assume success if set
             pass
        elif actual_val != follow_up_value:
             pass

    # CRITICAL: Validate meeting date is set if we have one (or warn if we don't)
    if final_date:
        if CF_MEETING_DATE not in cf_map:
            issues.append(f"❌ Meeting Date field not set! (Expected {final_date})")
            validation_passed = False
    else:
        issues.append("⚠️  Meeting Date was NOT parsed or provided. Please set it manually.")
        
    # Check description
    if not task_data.get('description'):
        issues.append("❌ description is empty")
        validation_passed = False

    # Report validation
    if issues:
        print("\n⚠️  Validation Issues:")
        for issue in issues:
            print(f"  {issue}")
    else:
        print("✅ All fields validated successfully")

    print(f"\n📋 Task Link: [{task_url}]({task_url})")

    return {
        'task_id': task_id,
        'task_url': task_url,
        'validation_passed': validation_passed,
        'issues': issues
    }




def check_shell_fragments(input_str):
    """Check for common shell fragments in unquoted input."""
    if not input_str:
        return False
    stripped = input_str.strip()
    if stripped.startswith('---') or stripped.startswith('- '):
        if len(stripped.split()) < 5:
            return True
    return False


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Create ClickUp Meeting Notes task')
    parser.add_argument('input', nargs='?', help='Direct meeting notes text (use quotes for multi-line)')
    parser.add_argument('--file', '-f', help='Path to meeting notes file (use for clarity)')
    parser.add_argument('--assignees', help='Comma-separated attendee names')
    parser.add_argument('--date', help='Meeting date (YYYY-MM-DD)')

    args = parser.parse_args()

    # Process input
    notes_text = ""
    
    if args.file:
        # Explicit --file flag
        if not os.path.exists(args.file):
            print("="*60)
            print(f"ERROR: File not found: {args.file}")
            print("="*60)
            print("Suggestion: Check file path and try again")
            print("="*60)
            sys.exit(1)
        try:
            with open(args.file, 'r', encoding='utf-8') as f:
                notes_text = f.read()
        except Exception as e:
            print(f"ERROR: Could not read file: {e}")
            sys.exit(1)
    elif args.input:
        # Check for shell fragments
        if check_shell_fragments(args.input):
            print("="*60)
            print("ERROR: Input appears unquoted")
            print("="*60)
            print("Suggestion: Wrap your meeting notes in quotes")
            print("Incorrect: python create_meeting_notes.py --- Notes")
            print("Correct: python create_meeting_notes.py '--- Notes'")
            print("="*60)
            sys.exit(1)
        
        # Check if it looks like a file path
        if os.path.exists(args.input) and os.path.isfile(args.input):
            try:
                with open(args.input, 'r', encoding='utf-8') as f:
                    notes_text = f.read()
            except Exception as e:
                print(f"ERROR: Could not read file: {e}")
                sys.exit(1)
        else:
            notes_text = args.input
    
    if not notes_text or not notes_text.strip():
        print("="*60)
        print("ERROR: No meeting notes content provided")
        print("="*60)
        sys.exit(1)

    # Parse meeting date if provided
    meeting_date = None
    if args.date:
        try:
            meeting_date = datetime.strptime(args.date, '%Y-%m-%d').date()
        except ValueError as e:
            print(f"❌ Invalid date format: {e}")
            sys.exit(1)

    # Create task
    create_meeting_notes(notes_text, meeting_date=meeting_date)
